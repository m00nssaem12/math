# 수학 탐험대

초등학교 1~6학년용 3문제 단위 수학 게임입니다. 학년별 핵심 단원을 제공하며, Firebase를 연결하지 않아도 브라우저에 최고 점수가 저장됩니다.

현재 포함된 학년별 범위: 1학년(수 세기·덧셈/뺄셈), 2학년(곱셈·나눗셈·길이), 3학년(나눗셈·분수·시간), 4학년(큰 수·각도·분수), 5학년(분수·소수·넓이·둘레), 6학년(비·백분율·원주율).

`review.html`에는 학년별 난이도를 고르는 **번개 계산** 복습 게임이 있습니다. 60초 동안 문제를 풀며 점수와 연속 정답을 기록합니다.

`match.html`에는 계산식과 답을 짝지어 보는 **카드 짝맞추기** 게임이 있습니다. 메인 탐험은 매번 학년별 고정 문제와 36개 자동 생성 문제를 섞어 5문제씩 출제합니다.

## 단일 포털 파일

`school-portal.html`은 학생·교사 화면을 하나로 합친 파일입니다. 학생은 발급받은 아이디로 로그인해 풀이 기록을 남기고, 교사는 같은 파일에서 학급 계정을 만들고 분석·CSV 내려받기를 할 수 있습니다. 파일 상단의 `firebaseConfig`에 웹 앱 설정을 넣고, 앞서 설명한 Cloud Functions를 배포해야 실제 계정 관리가 동작합니다.

## Firebase 연결

1. [Firebase Console](https://console.firebase.google.com/)에서 프로젝트를 만들고 **웹 앱**을 등록합니다.
2. **Authentication → Sign-in method**에서 `익명` 로그인을 사용 설정합니다.
3. **Firestore Database**를 만들고, 테스트 단계에서는 아래 규칙을 사용합니다. 실제 공개 전에는 사용자별 검증 규칙으로 꼭 강화하세요.

```txt
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /scores/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

4. `app.js`의 `const firebaseConfig = null`을 Firebase Console의 설정 객체로 바꿉니다. API 키는 웹 앱에 노출되어도 되는 식별자지만, Firestore 보안 규칙은 절대 열어 두지 마세요.

## 교사·학생 계정 기능

`teacher.html`은 교사용 화면입니다. 교사가 로그인하면 학급 코드와 학생 이름 목록으로 최대 100명의 계정을 한 번에 생성합니다. 실제 생성은 브라우저가 아닌 Cloud Functions의 Admin SDK가 처리하므로, 학생 계정 생성 권한을 클라이언트에 노출하지 않습니다.

설정 순서:

1. Firebase Authentication에서 **이메일/비밀번호** 로그인 방식을 활성화하고, Firebase Console에서 교사 계정을 만듭니다.
2. Firebase CLI로 Functions를 초기화한 뒤 이 폴더의 `firebase/functions` 내용을 Functions 프로젝트에 넣고 `firebase deploy --only functions,firestore:rules`로 배포합니다. Cloud Functions 배포에는 Firebase의 결제 플랜이 필요할 수 있습니다.
3. 최초 교사 계정에 신뢰된 서버 환경에서 `teacher: true` 커스텀 클레임을 부여합니다. 이 역할은 브라우저에서 만들면 안 됩니다.
4. `teacher.js`에도 웹 앱 Firebase 설정을 입력합니다. 이제 `/teacher.html`에서 학생을 등록할 수 있습니다.

학생 로그인 ID는 `학급코드-번호` 형식이며, 이메일처럼 보이도록 서버에서 내부 주소를 붙입니다. 임시 비밀번호는 생성 응답에만 포함되고 Firestore에는 저장하지 않습니다. 개인 정보 보호를 위해 이름 외의 식별 정보는 넣지 않는 것을 권장합니다.

교사 화면에서는 **학급 분석 보기**로 학생별 풀이 수·정답률·취약 학년 영역·추천을 확인할 수 있고, **결과 CSV 내려받기**로 Excel용 파일을 만들 수 있습니다. 분석은 정답 기록을 기준으로 서버에서 계산합니다. 학생은 메인 화면의 로그인 버튼에서 발급받은 아이디와 임시 비밀번호로 로그인합니다.

## GitHub Pages 배포

1. 이 폴더를 새 GitHub 저장소의 루트에 올립니다.
2. 저장소 **Settings → Pages → Build and deployment**에서 `Deploy from a branch`, `main`, `/(root)`를 선택합니다.
3. 제공된 Pages 주소에서 확인합니다. Firebase Authentication의 **Authorized domains**에 `<계정>.github.io`를 추가합니다.

로컬 미리보기는 VS Code Live Server처럼 정적 웹 서버로 열면 됩니다. `file://`로 직접 열면 모듈 보안 정책 때문에 동작하지 않을 수 있습니다.
