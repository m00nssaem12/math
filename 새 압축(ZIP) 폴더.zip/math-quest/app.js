// Firebase를 쓸 때 README의 firebaseConfig로 교체하세요.
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getAuth, signInAnonymously, signInWithEmailAndPassword } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import { getFirestore, doc, getDoc, setDoc } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import { getFunctions, httpsCallable } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-functions.js';

const firebaseConfig = null; // { apiKey: '...', authDomain: '...', projectId: '...', ... }
let db, uid, functions;
if (firebaseConfig) {
  const app = initializeApp(firebaseConfig);
  db = getFirestore(app); functions = getFunctions(app, 'asia-northeast3');
  signInAnonymously(getAuth(app)).then(({ user }) => { uid = user.uid; loadCloudScore(); }).catch(console.error);
}

const banks = {
  fraction: [
    ['피자 8조각 중 3조각을 먹었어요. 먹은 부분을 분수로 나타내면?', ['3/8','5/8','3/5','8/3'], 0, '분자는 먹은 조각, 분모는 전체 조각이에요.'],
    ['2/5와 크기가 같은 분수는?', ['4/10','3/10','5/2','2/10'], 0, '분자와 분모에 같은 수 2를 곱하면 4/10이 돼요.'],
    ['7/9에서 분모는 무엇일까요?', ['7','9','16','2'], 1, '분모는 아래에 있는 수예요.']
  ],
  decimal: [
    ['3.47에서 소수 첫째 자리의 숫자는?', ['3','4','7','47'], 1, '소수점 바로 오른쪽이 소수 첫째 자리예요.'],
    ['0.8과 같은 수는?', ['8/10','8/100','80','0.08'], 0, '0.8은 10분의 8이에요.'],
    ['1.25 + 0.5의 값은?', ['1.30','1.75','1.80','0.75'], 1, '소수점을 맞춰 1.25 + 0.50으로 계산해요.']
  ],
  area: [
    ['가로 6cm, 세로 4cm인 직사각형의 넓이는?', ['10㎠','20㎠','24㎠','48㎠'], 2, '직사각형 넓이 = 가로 × 세로예요.'],
    ['한 변이 5cm인 정사각형의 넓이는?', ['10㎠','20㎠','25㎠','30㎠'], 2, '정사각형 넓이 = 한 변 × 한 변이에요.'],
    ['넓이의 단위로 알맞은 것은?', ['cm','cm²','kg','L'], 1, '넓이는 제곱센티미터(cm²)를 써요.']
  ]
};
banks.grade1 = [
  ['7 + 5의 값은?', ['11','12','13','14'], 1, '7에서 5만큼 더 세어 보세요.'], ['15 - 8의 값은?', ['6','7','8','9'], 1, '15에서 8을 빼면 7이에요.'], ['다음 수는 무엇일까요? 18, 19, __, 21', ['17','20','22','29'], 1, '한 개씩 커지는 수예요.']
];
banks.grade2 = [
  ['4 × 3의 값은?', ['7','12','16','43'], 1, '4가 3번 있는 수예요.'], ['18 ÷ 2의 값은?', ['8','9','10','16'], 1, '18을 똑같이 2묶음으로 나눠요.'], ['1m는 몇 cm일까요?', ['10cm','50cm','100cm','1000cm'], 2, '1m = 100cm예요.']
];
banks.grade3 = [
  ['24 ÷ 6의 값은?', ['3','4','5','6'], 1, '6 × 4 = 24예요.'], ['1/2은 전체를 몇 부분으로 똑같이 나눈 것일까요?', ['1','2','3','4'], 1, '분모는 전체를 똑같이 나눈 수예요.'], ['오전 9시에서 2시간 뒤는?', ['오전 10시','오전 11시','오후 11시','오후 1시'], 1, '9에 2를 더해 보세요.']
];
banks.grade4 = [
  ['3,405에서 4가 나타내는 값은?', ['4','40','400','4,000'], 2, '4는 백의 자리예요.'], ['직각은 몇 도일까요?', ['45°','90°','180°','360°'], 1, '직각은 네모 모서리와 같은 각이에요.'], ['3/4 + 1/4의 값은?', ['1/2','1','4/8','3/8'], 1, '분모가 같으면 분자끼리 더해요.']
];
banks.grade5 = [...banks.fraction, ...banks.decimal, ...banks.area];
banks.grade6 = [
  ['2 : 3에서 앞의 수는?', ['2','3','5','6'], 0, '비는 앞의 수 : 뒤의 수로 읽어요.'], ['100의 25%는?', ['4','25','50','75'], 1, '25%는 100개 중 25개예요.'], ['원의 둘레를 구할 때 사용하는 값은?', ['반지름','지름','원주율','넓이'], 2, '원주율은 원의 둘레와 지름의 관계를 나타내요.']
];
banks.grade1.push(
  ['9 + 8의 값은?', ['16','17','18','19'], 1, '9에 8을 더하면 17이에요.'],
  ['20보다 1 작은 수는?', ['18','19','20','21'], 1, '한 개 적은 수를 생각해요.'],
  ['13은 10과 몇으로 이루어졌을까요?', ['1','2','3','13'], 2, '13 = 10 + 3이에요.'],
  ['사과가 6개, 배가 4개예요. 모두 몇 개일까요?', ['2','10','12','24'], 1, '서로 다른 과일의 수를 더해요.']
);
banks.grade2.push(
  ['5 × 6의 값은?', ['11','25','30','56'], 2, '5가 6번 있는 수예요.'],
  ['35 + 27의 값은?', ['52','62','72','82'], 1, '십의 자리와 일의 자리를 더해요.'],
  ['500원짜리 2개는 모두 얼마일까요?', ['700원','1,000원','1,500원','2,000원'], 1, '500 + 500을 계산해요.'],
  ['삼각형의 변은 몇 개일까요?', ['2개','3개','4개','5개'], 1, '삼각형은 세 변으로 이루어져요.']
);
banks.grade3.push(
  ['36 ÷ 4의 값은?', ['8','9','10','12'], 1, '4 × 9 = 36이에요.'],
  ['1/3에서 분자는 무엇일까요?', ['1','3','4','13'], 0, '분수의 위쪽 수가 분자예요.'],
  ['1시간 30분은 모두 몇 분일까요?', ['60분','90분','100분','130분'], 1, '1시간은 60분이에요.'],
  ['가로 5cm, 세로 3cm 직사각형의 둘레는?', ['8cm','15cm','16cm','30cm'], 2, '네 변의 길이를 모두 더해요.']
);
banks.grade4.push(
  ['45°보다 큰 각은?', ['30°','45°','90°','20°'], 2, '90은 45보다 커요.'],
  ['2,000 + 300 + 40 + 5는?', ['2,345','2,305','2,435','2,034'], 0, '각 자리의 값을 더해요.'],
  ['1/2와 2/4의 관계는?', ['1/2가 더 크다','2/4가 더 크다','크기가 같다','알 수 없다'], 2, '2/4는 분자와 분모를 2로 나눈 수예요.'],
  ['평행한 두 직선은?', ['언젠가 만난다','절대 만나지 않는다','항상 직각이다','길이가 같다'], 1, '나란히 뻗어 만나지 않아요.']
);
banks.grade5.push(
  ['4.2 + 1.35의 값은?', ['5.55','5.35','4.65','6.55'], 0, '소수점을 맞춰 더해요.'],
  ['3/8보다 큰 분수는?', ['1/8','2/8','4/8','3/9'], 2, '분모가 같으면 분자가 큰 분수가 더 커요.'],
  ['밑변 8cm, 높이 5cm인 평행사변형의 넓이는?', ['13㎠','20㎠','40㎠','80㎠'], 2, '평행사변형 넓이 = 밑변 × 높이예요.'],
  ['2.7을 10배 하면?', ['0.27','2.7','27','270'], 2, '소수점이 오른쪽으로 한 칸 움직여요.']
);
banks.grade6.push(
  ['3 : 4와 같은 비는?', ['6 : 8','4 : 3','3 : 8','7 : 8'], 0, '두 수에 같은 수 2를 곱했어요.'],
  ['80의 50%는?', ['20','30','40','50'], 2, '50%는 절반이에요.'],
  ['반지름이 4cm인 원의 지름은?', ['2cm','4cm','8cm','16cm'], 2, '지름은 반지름의 2배예요.'],
  ['2/3 ÷ 1/3의 값은?', ['1/3','1','2','3'], 2, '1/3이 2개 있어요.']
);
function choices(correct) {
  const set = new Set([correct]); let gap = 1;
  while (set.size < 4) { const value = Math.max(0, correct + (set.size % 2 ? gap : -gap)); set.add(value); gap += Math.max(1, Math.ceil(Math.abs(correct) / 8)); }
  return [...set].sort(() => Math.random() - .5).map(String);
}
function numericQuestion(text, correct, hint) { const answers = choices(correct); return [text, answers, answers.indexOf(String(correct)), hint]; }
function generatedQuestions(grade) {
  const out = [];
  for (let i = 0; i < 36; i++) {
    let a, b, d;
    if (grade === 1) { a = Math.floor(Math.random() * 10) + 1; b = Math.floor(Math.random() * (20 - a)) + 1; out.push(i % 2 ? numericQuestion(`${a + b} - ${a}의 값은?`, b, '앞의 수에서 뒤의 수를 빼요.') : numericQuestion(`${a} + ${b}의 값은?`, a + b, '수를 차례대로 더해요.')); }
    else if (grade === 2) { a = Math.floor(Math.random() * 80) + 10; b = Math.floor(Math.random() * 20) + 1; out.push(i % 3 ? numericQuestion(`${a} + ${b}의 값은?`, a + b, '십의 자리와 일의 자리를 더해요.') : numericQuestion(`${(i % 8) + 2} × ${Math.floor(Math.random() * 8) + 2}의 값은?`, ((i % 8) + 2) * (Math.floor(Math.random() * 8) + 2), '같은 수를 여러 번 더해요.')); }
    else if (grade === 3) { a = Math.floor(Math.random() * 8) + 2; b = Math.floor(Math.random() * 8) + 2; out.push(i % 2 ? numericQuestion(`${a * b} ÷ ${a}의 값은?`, b, '나눗셈은 곱셈의 반대예요.') : numericQuestion(`${a} × ${b}의 값은?`, a * b, '구구단을 떠올려 보세요.')); }
    else if (grade === 4) { a = Math.floor(Math.random() * 7000) + 1000; b = Math.floor(Math.random() * 900) + 100; out.push(i % 2 ? numericQuestion(`${a + b}의 값은?`, a + b, '자릿수를 맞춰 더해요.') : numericQuestion(`${a + b} - ${a}의 값은?`, b, '큰 수의 뺄셈도 자릿수를 맞춰요.')); }
    else if (grade === 5) { a = Math.floor(Math.random() * 80) / 10 + 1; b = Math.floor(Math.random() * 40) / 10 + 0.1; d = [2, 4, 5, 10][i % 4]; out.push(i % 2 ? numericQuestion(`${a.toFixed(1)} + ${b.toFixed(1)}의 값은?`, +(a + b).toFixed(1), '소수점을 맞춰 계산해요.') : numericQuestion(`${Math.floor(Math.random() * (d - 1)) + 1}/${d}에서 분모는?`, d, '분모는 아래쪽 수예요.')); }
    else { a = [20, 25, 50, 75][i % 4]; b = [40, 80, 120, 200][i % 4]; out.push(i % 2 ? numericQuestion(`${b}의 ${a}%는?`, b * a / 100, '백분율은 100분의 몇이에요.') : numericQuestion(`2 : 3에서 앞의 수를 4배 하면?`, 8, '비의 두 수에 같은 수를 곱해요.')); }
  }
  return out;
}
const topicNames = { grade1: '1학년 수학 탐험', grade2: '2학년 수학 탐험', grade3: '3학년 수학 탐험', grade4: '4학년 수학 탐험', grade5: '5학년 수학 탐험', grade6: '6학년 수학 탐험' };
let topic = 'grade5', questions = [], index = 0, stars = 0, answered = false, finished = false;
const $ = id => document.getElementById(id);
const profileKey = 'mathQuestProfile';
let profile = JSON.parse(localStorage.getItem(profileKey) || '{}');
profile = { total: 0, daily: 0, dailyDate: '', comboBest: 0, badges: [], ...profile };
let combo = 0;
const today = () => new Date().toISOString().slice(0, 10);
function updateProfile() {
  if (profile.dailyDate !== today()) { profile.dailyDate = today(); profile.daily = 0; }
  localStorage.setItem(profileKey, JSON.stringify(profile));
  $('total-stars').textContent = profile.total;
  $('daily-stars').textContent = profile.daily;
  $('daily-progress-bar').style.width = `${Math.min(100, profile.daily * 10)}%`;
  $('level-number').textContent = Math.floor(profile.total / 15) + 1;
  $('combo-count').textContent = `${combo} 콤보`;
  document.querySelectorAll('.badge').forEach(el => el.classList.toggle('locked', !profile.badges.includes(el.dataset.badge)));
}
function unlock(id) { if (!profile.badges.includes(id)) profile.badges.push(id); }

function setQuestions() {
  questions = [...banks[topic], ...generatedQuestions(+topic.replace('grade', ''))].sort(() => Math.random() - .5).slice(0, 5);
  index = 0; stars = 0; combo = 0; finished = false; render();
}
function render() {
  answered = false;
  const q = questions[index];
  $('topic-label').textContent = topicNames[topic]; $('question-count').textContent = `문제 ${index + 1} / ${questions.length}`;
  $('progress-bar').style.width = `${index / questions.length * 100}%`; $('round-stars').textContent = `★ ${stars}`;
  $('question').textContent = q[0]; $('feedback').textContent = ''; $('next-button').hidden = true;
  $('answers').innerHTML = q[1].map((answer, i) => `<button class="answer" data-index="${i}">${answer}</button>`).join('');
  document.querySelectorAll('.answer').forEach(button => button.addEventListener('click', () => answer(+button.dataset.index)));
}
function answer(choice) {
  if (answered) return; answered = true;
  const q = questions[index], isCorrect = choice === q[2];
  document.querySelectorAll('.answer').forEach((button, i) => { button.disabled = true; button.classList.add(i === q[2] ? 'correct' : i === choice ? 'wrong' : ''); });
  if (isCorrect) { stars++; combo++; profile.total++; profile.daily++; profile.comboBest = Math.max(profile.comboBest, combo); if (profile.total === 1) unlock('first'); if (combo >= 3) unlock('combo'); $('feedback').textContent = combo >= 3 ? `정답! ${combo}콤보 달성! 🔥` : '정답! 별 하나를 얻었어요! ✨'; } else { combo = 0; $('feedback').textContent = `아쉬워요. ${q[3]}`; }
  updateProfile();
  if (functions) httpsCallable(functions, 'recordStudentAttempt')({ topic, correct: isCorrect }).catch(() => {});
  $('round-stars').textContent = `★ ${stars}`; $('next-button').textContent = index === questions.length - 1 ? '결과 보기 ★' : '다음 문제 →'; $('next-button').hidden = false;
}
$('next-button').addEventListener('click', () => { if (finished) { setQuestions(); return; } if (++index < questions.length) render(); else { finished = true; finish(); } });
function finish() { if (stars === questions.length) unlock('perfect'); updateProfile(); $('progress-bar').style.width = '100%'; $('question').textContent = `탐험 완료! 별 ${stars}개를 모았어요.`; $('answers').innerHTML = ''; $('feedback').textContent = stars === questions.length ? '완벽해요! 오늘의 수학 탐험가예요. 🏆' : '잘했어요! 다시 도전하면 더 많은 별을 모을 수 있어요.'; $('next-button').textContent = '한 번 더 하기'; $('next-button').hidden = false; saveScore(); }
document.querySelectorAll('.subject-card').forEach(card => card.addEventListener('click', () => { document.querySelector('.subject-card.active').classList.remove('active'); card.classList.add('active'); topic = card.dataset.topic; setQuestions(); }));
function localBest() { return +localStorage.getItem('mathQuestBest') || 0; }
function showBest(n) { $('best-score').textContent = n; $('total-stars').textContent = n; }
async function loadCloudScore() { try { const saved = await getDoc(doc(db, 'scores', uid)); showBest(Math.max(localBest(), saved.exists() ? saved.data().best || 0 : 0)); } catch { showBest(localBest()); } }
async function saveScore() { const best = Math.max(localBest(), stars); localStorage.setItem('mathQuestBest', best); showBest(best); if (db && uid) try { await setDoc(doc(db, 'scores', uid), { best, updatedAt: new Date().toISOString() }, { merge: true }); } catch (e) { console.warn('점수 저장 실패', e); } }
const dialog = $('name-dialog'); $('sign-in-button').addEventListener('click', async () => { if (!firebaseConfig) { dialog.showModal(); return; } const id = prompt('학생 아이디 또는 교사 이메일'); const password = prompt('비밀번호'); if (!id || !password) return; const email = id.includes('@') ? id : `${id}@student.mathquest.local`; try { const result = await signInWithEmailAndPassword(getAuth(), email, password); uid = result.user.uid; $('player-name').textContent = `${result.user.displayName || '탐험가'} 탐험가`; loadCloudScore(); } catch (e) { alert(`로그인할 수 없어요: ${e.message}`); } }); dialog.addEventListener('close', () => { const name = $('name-input').value.trim(); if (name) { localStorage.setItem('mathQuestName', name); $('player-name').textContent = `${name} 탐험가`; } });
$('player-name').textContent = `${localStorage.getItem('mathQuestName') || '탐험가'}`; showBest(localBest()); updateProfile(); setQuestions();
