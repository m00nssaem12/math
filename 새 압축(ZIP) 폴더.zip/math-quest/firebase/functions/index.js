const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const crypto = require('crypto');

initializeApp();
const db = getFirestore();

function requireTeacher(request) {
  if (!request.auth) throw new HttpsError('unauthenticated', '로그인이 필요합니다.');
  if (request.auth.token.teacher !== true) throw new HttpsError('permission-denied', '교사 계정만 사용할 수 있습니다.');
}
function tempPassword() {
  return crypto.randomBytes(9).toString('base64url');
}

// 교사가 한 줄에 한 명씩 이름을 보내면 학생 계정을 만듭니다.
// 반환되는 임시 비밀번호는 이 호출에서만 제공하며 Firestore에는 저장하지 않습니다.
exports.createStudents = onCall({ region: 'asia-northeast3' }, async (request) => {
  requireTeacher(request);
  const { classCode, students } = request.data || {};
  if (!/^[a-z0-9-]{3,30}$/i.test(classCode || '')) throw new HttpsError('invalid-argument', '학급 코드를 확인하세요.');
  if (!Array.isArray(students) || students.length < 1 || students.length > 100) throw new HttpsError('invalid-argument', '학생은 한 번에 1~100명만 등록할 수 있습니다.');

  const result = [];
  for (const [index, rawName] of students.entries()) {
    const name = String(rawName).trim().replace(/\s+/g, ' ');
    if (!/^[가-힣a-zA-Z]{2,20}( [가-힣a-zA-Z]{2,20})?$/.test(name)) throw new HttpsError('invalid-argument', `${index + 1}번째 이름을 확인하세요.`);
    const loginId = `${classCode}-${String(index + 1).padStart(2, '0')}`.toLowerCase();
    const email = `${loginId}@student.mathquest.local`;
    const password = tempPassword();
    try {
      const user = await getAuth().createUser({ email, password, displayName: name });
      await getAuth().setCustomUserClaims(user.uid, { student: true, classCode });
      await db.doc(`classes/${classCode}/students/${user.uid}`).set({ name, loginId, createdAt: FieldValue.serverTimestamp(), teacherUid: request.auth.uid, attempts: 0, correct: 0, topicStats: {} });
      result.push({ name, loginId, password });
    } catch (error) {
      if (error.code === 'auth/email-already-exists') throw new HttpsError('already-exists', `${loginId} 계정이 이미 있습니다.`);
      throw new HttpsError('internal', '계정 생성 중 오류가 발생했습니다.');
    }
  }
  return { students: result };
});

// 최초 교사는 Firebase Console 또는 신뢰된 관리 스크립트로 teacher 클레임을 부여해야 합니다.
exports.recordStudentAttempt = onCall({ region: 'asia-northeast3' }, async (request) => {
  if (!request.auth || request.auth.token.student !== true) throw new HttpsError('permission-denied', '학생 계정만 기록할 수 있습니다.');
  const { topic, correct } = request.data || {}, classCode = request.auth.token.classCode;
  if (!/^grade[1-6]$/.test(topic || '') || typeof correct !== 'boolean') throw new HttpsError('invalid-argument', '학습 기록 형식이 올바르지 않습니다.');
  const ref = db.doc(`classes/${classCode}/students/${request.auth.uid}`);
  await db.runTransaction(async tx => {
    const snap = await tx.get(ref); if (!snap.exists) throw new HttpsError('not-found', '학생 명단을 찾을 수 없습니다.');
    const stats = snap.data().topicStats || {}, before = stats[topic] || { attempts: 0, correct: 0 };
    stats[topic] = { attempts: before.attempts + 1, correct: before.correct + (correct ? 1 : 0) };
    tx.update(ref, { attempts: FieldValue.increment(1), correct: FieldValue.increment(correct ? 1 : 0), topicStats: stats, lastStudiedAt: FieldValue.serverTimestamp() });
  });
  return { ok: true };
});
function analysisFor(student) {
  const attempts = student.attempts || 0, correct = student.correct || 0, rate = attempts ? Math.round(correct / attempts * 100) : null;
  const topics = Object.entries(student.topicStats || {}).map(([topic, value]) => ({ topic, attempts: value.attempts || 0, rate: value.attempts ? Math.round((value.correct || 0) / value.attempts * 100) : 0 }));
  const weak = topics.filter(x => x.attempts >= 3).sort((a, b) => a.rate - b.rate)[0];
  return { attempts, correct, rate, weakTopic: weak?.topic || null, message: !attempts ? '아직 학습 기록이 없습니다.' : rate >= 85 ? '도전 문제를 권장해요.' : rate >= 60 ? '현재 수준에 맞는 반복 연습이 좋아요.' : `${weak ? `${weak.topic.replace('grade', '')}학년 영역` : '기초 영역'}을 천천히 복습해 보세요.` };
}
exports.getClassSummary = onCall({ region: 'asia-northeast3' }, async (request) => {
  requireTeacher(request);
  const classCode = String(request.data?.classCode || '');
  const snapshot = await db.collection(`classes/${classCode}/students`).where('teacherUid', '==', request.auth.uid).get();
  const students = snapshot.docs.map(d => { const data = { id: d.id, ...d.data() }; return { ...data, analysis: analysisFor(data) }; });
  return { count: students.length, students };
});
