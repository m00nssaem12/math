import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getAuth, signInWithEmailAndPassword } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import { getFunctions, httpsCallable } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-functions.js';

const firebaseConfig = null; // app.js와 같은 Firebase 웹 앱 설정을 입력하세요.
const message = document.querySelector('#message');
if (!firebaseConfig) message.textContent = 'Firebase 설정을 teacher.js에 입력하면 교사 기능을 사용할 수 있습니다.';
else {
  const app = initializeApp(firebaseConfig), auth = getAuth(app), functions = getFunctions(app, 'asia-northeast3');
  let latest = [];
  document.querySelector('#login').onclick = async () => {
    const email = prompt('교사 이메일'), password = prompt('비밀번호'); if (!email || !password) return;
    try { const credential = await signInWithEmailAndPassword(auth, email, password); const token = await credential.user.getIdTokenResult(true); if (token.claims.teacher !== true) throw new Error('이 계정에는 교사 권한이 없습니다.'); document.querySelector('#bulk-form').hidden = false; document.querySelector('#class-tools').hidden = false; message.textContent = '교사 인증 완료'; } catch (e) { message.textContent = e.message; }
  };
  document.querySelector('#bulk-form').onsubmit = async e => {
    e.preventDefault(); const classCode = document.querySelector('#class-code').value.trim(), students = document.querySelector('#students').value.split('\n').map(x => x.trim()).filter(Boolean);
    try { message.textContent = '계정을 만들고 있어요…'; const { data } = await httpsCallable(functions, 'createStudents')({ classCode, students }); const text = data.students.map(s => `${s.name}\t아이디: ${s.loginId}\t임시 비밀번호: ${s.password}`).join('\n'); const out = document.querySelector('#result'); out.hidden = false; out.textContent = text; message.textContent = `${data.students.length}명 생성 완료. 아래 내용을 안전하게 전달하세요.`; } catch (e) { message.textContent = e.message; }
  };
  async function loadClass() { const classCode = document.querySelector('#class-code').value.trim(); if (!classCode) throw new Error('먼저 학급 코드를 입력하세요.'); const { data } = await httpsCallable(functions, 'getClassSummary')({ classCode }); latest = data.students; const text = latest.map(s => `${s.name} (${s.loginId}) | 정답률: ${s.analysis.rate ?? '-'}% | ${s.analysis.message}`).join('\n'); const out = document.querySelector('#result'); out.hidden = false; out.textContent = `학생 ${data.count}명\n\n${text || '등록된 학생이 없습니다.'}`; }
  document.querySelector('#load-class').onclick = async () => { try { message.textContent = '학습 기록을 분석하고 있어요…'; await loadClass(); message.textContent = '분석 완료'; } catch (e) { message.textContent = e.message; } };
  document.querySelector('#download-csv').onclick = async () => { try { if (!latest.length) await loadClass(); const rows = [['이름','로그인 ID','풀이 수','정답 수','정답률','취약 영역','추천']].concat(latest.map(s => [s.name,s.loginId,s.analysis.attempts,s.analysis.correct,`${s.analysis.rate ?? ''}%`,s.analysis.weakTopic || '',s.analysis.message])); const csv = '\ufeff' + rows.map(row => row.map(v => `"${String(v).replaceAll('"','""')}"`).join(',')).join('\n'); const link = Object.assign(document.createElement('a'), { href: URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })), download: `math-quest-${document.querySelector('#class-code').value || 'class'}.csv` }); link.click(); URL.revokeObjectURL(link.href); } catch (e) { message.textContent = e.message; } };
}
